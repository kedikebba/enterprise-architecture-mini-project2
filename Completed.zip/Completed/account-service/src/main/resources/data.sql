USE account;
INSERT IGNORE INTO `account`.`roles` (`id`, `name`) VALUES ('1', 'ADMIN');
INSERT IGNORE INTO `account`.`roles` (`id`, `name`) VALUES ('2', 'USER');
